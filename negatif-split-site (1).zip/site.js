/* ====== RÉGLAGES DU SITE : c'est ici que tu modifies le nom et les onglets ====== */
const NOM = "Négatif Split";
const ONGLETS = [
  ["index.html", "Accueil"],
  ["connaissances.html", "Connaissances"],
  ["estimateur.html", "Estimateur"],
  ["marche.html", "Marché"],
  // Pour ajouter un onglet : ajoute une ligne ["nom-du-fichier.html", "Nom affiché"],
  // puis crée le fichier en copiant modele-onglet.html
];
/* ====== Ne touche pas à la suite ====== */
(function(){
  const fichier = location.pathname.split("/").pop() || "index.html";
  const nav = ONGLETS.map(([f,l]) => `<a href="${f}"${f===fichier?' class="on"':''}>${l}</a>`).join("");
  document.getElementById("header").outerHTML = `<header><a class="logo" href="index.html">${NOM}</a><nav>${nav}</nav></header>`;
  document.getElementById("footer").outerHTML = `<footer>${NOM} – en construction.</footer>`;
  document.title = document.title + " – " + NOM;
})();
