const dists=[[5,"5 km"],[10,"10 km"],[21.0975,"Semi-marathon"],[42.195,"Marathon"]];
const $=id=>document.getElementById(id);
function fmt(t){t=Math.round(t);const h=Math.floor(t/3600),m=Math.floor(t%3600/60),s=t%60,p=n=>String(n).padStart(2,"0");return h?`${h}:${p(m)}:${p(s)}`:`${m}:${p(s)}`}
function calc(){
const d=parseFloat($("d").value),h=+$("h").value||0,m=+$("m").value||0,s=+$("s").value||0;
const t=h*3600+m*60+s,out=$("out"),err=$("err");
if(t<=0||m>59||s>59||h<0||m<0||s<0){err.textContent="Entre un temps valide (minutes et secondes entre 0 et 59).";out.innerHTML="";return}
err.textContent="";
out.innerHTML=dists.map(([km,name])=>{const ref=km===d,est=ref?t:t*Math.pow(km/d,1.06);
return `<tr class="${ref?"ref":""}"><td>${name}</td><td class="t">${fmt(est)}</td><td>${fmt(est/km)} /km</td></tr>`}).join("")}
["d","h","m","s"].forEach(i=>$(i).addEventListener("input",calc));
calc();
